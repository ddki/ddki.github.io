
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'hashsum' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'hashsum'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'hashsum' {
            [CompletionResult]::new('--bits', 'bits', [CompletionResultType]::ParameterName, 'set the size of the output (only for SHAKE)')
            [CompletionResult]::new('-b', 'b', [CompletionResultType]::ParameterName, 'read in binary mode (default)')
            [CompletionResult]::new('--binary', 'binary', [CompletionResultType]::ParameterName, 'read in binary mode (default)')
            [CompletionResult]::new('-c', 'c', [CompletionResultType]::ParameterName, 'read hashsums from the FILEs and check them')
            [CompletionResult]::new('--check', 'check', [CompletionResultType]::ParameterName, 'read hashsums from the FILEs and check them')
            [CompletionResult]::new('--tag', 'tag', [CompletionResultType]::ParameterName, 'create a BSD-style checksum')
            [CompletionResult]::new('-t', 't', [CompletionResultType]::ParameterName, 'read in text mode')
            [CompletionResult]::new('--text', 'text', [CompletionResultType]::ParameterName, 'read in text mode')
            [CompletionResult]::new('-q', 'q', [CompletionResultType]::ParameterName, 'don''t print OK for each successfully verified file')
            [CompletionResult]::new('--quiet', 'quiet', [CompletionResultType]::ParameterName, 'don''t print OK for each successfully verified file')
            [CompletionResult]::new('-s', 's', [CompletionResultType]::ParameterName, 'don''t output anything, status code shows success')
            [CompletionResult]::new('--status', 'status', [CompletionResultType]::ParameterName, 'don''t output anything, status code shows success')
            [CompletionResult]::new('--strict', 'strict', [CompletionResultType]::ParameterName, 'exit non-zero for improperly formatted checksum lines')
            [CompletionResult]::new('-w', 'w', [CompletionResultType]::ParameterName, 'warn about improperly formatted checksum lines')
            [CompletionResult]::new('--warn', 'warn', [CompletionResultType]::ParameterName, 'warn about improperly formatted checksum lines')
            [CompletionResult]::new('-z', 'z', [CompletionResultType]::ParameterName, 'end each output line with NUL, not newline')
            [CompletionResult]::new('--zero', 'zero', [CompletionResultType]::ParameterName, 'end each output line with NUL, not newline')
            [CompletionResult]::new('--no-names', 'no-names', [CompletionResultType]::ParameterName, 'Omits filenames in the output (option not present in GNU/Coreutils)')
            [CompletionResult]::new('--md5', 'md5', [CompletionResultType]::ParameterName, 'work with MD5')
            [CompletionResult]::new('--sha1', 'sha1', [CompletionResultType]::ParameterName, 'work with SHA1')
            [CompletionResult]::new('--sha224', 'sha224', [CompletionResultType]::ParameterName, 'work with SHA224')
            [CompletionResult]::new('--sha256', 'sha256', [CompletionResultType]::ParameterName, 'work with SHA256')
            [CompletionResult]::new('--sha384', 'sha384', [CompletionResultType]::ParameterName, 'work with SHA384')
            [CompletionResult]::new('--sha512', 'sha512', [CompletionResultType]::ParameterName, 'work with SHA512')
            [CompletionResult]::new('--sha3', 'sha3', [CompletionResultType]::ParameterName, 'work with SHA3')
            [CompletionResult]::new('--sha3-224', 'sha3-224', [CompletionResultType]::ParameterName, 'work with SHA3-224')
            [CompletionResult]::new('--sha3-256', 'sha3-256', [CompletionResultType]::ParameterName, 'work with SHA3-256')
            [CompletionResult]::new('--sha3-384', 'sha3-384', [CompletionResultType]::ParameterName, 'work with SHA3-384')
            [CompletionResult]::new('--sha3-512', 'sha3-512', [CompletionResultType]::ParameterName, 'work with SHA3-512')
            [CompletionResult]::new('--shake128', 'shake128', [CompletionResultType]::ParameterName, 'work with SHAKE128 using BITS for the output size')
            [CompletionResult]::new('--shake256', 'shake256', [CompletionResultType]::ParameterName, 'work with SHAKE256 using BITS for the output size')
            [CompletionResult]::new('--b2sum', 'b2sum', [CompletionResultType]::ParameterName, 'work with BLAKE2')
            [CompletionResult]::new('--b3sum', 'b3sum', [CompletionResultType]::ParameterName, 'work with BLAKE3')
            [CompletionResult]::new('-h', 'h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', 'help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('-V', 'V ', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('--version', 'version', [CompletionResultType]::ParameterName, 'Print version')
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
